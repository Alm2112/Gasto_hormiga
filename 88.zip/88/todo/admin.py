from django.contrib import admin
from .models import Gasto
admin.site.register(Gasto)
